package com.amdocs.authorization.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.amdocs.authorization.dao.UserRequest;
import com.amdocs.authorization.dao.UserResponse;
import com.amdocs.authorization.model.UserAuth;
import com.amdocs.authorization.repository.UserAuthRepository;

@Service
public class UserAuthServiceImpl implements UserAuthService{

	@Autowired
	private UserAuthRepository userAuthRepository;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	@Autowired
	private JwtService jwtService;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Override
	public String authenticateUser(UserRequest request) {
		
		
		authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                		request.getUsername(),
                		request.getPassword()
                )
        );
		
		String token = jwtService.generateToken(userAuthRepository.findByUsername(request.getUsername()).get());
		
		return token;
	}

	public UserResponse signup(UserRequest input) {
		UserResponse response = new UserResponse();
		UserAuth user = new UserAuth();
		user.setUsername(input.getUsername());
		user.setPassword(passwordEncoder.encode(input.getPassword()));

        UserAuth savedUser = userAuthRepository.save(user);
        
        response.setCreatedDate(new Date());
        response.setUsername(savedUser.getUsername());
        
        return response;
        
    }
	
}
