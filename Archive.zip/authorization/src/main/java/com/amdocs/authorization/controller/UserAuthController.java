package com.amdocs.authorization.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amdocs.authorization.dao.UserRequest;
import com.amdocs.authorization.dao.UserResponse;
import com.amdocs.authorization.service.UserAuthService;

@RestController
@RequestMapping("/auth")
public class UserAuthController {
	
	@Autowired
	private UserAuthService userAuthService;

	@PostMapping("/login")
	public ResponseEntity<String> authenticateUser(@RequestBody UserRequest request){
		String token = userAuthService.authenticateUser(request);
		if(token.length() > 0){
			return ResponseEntity.ok(token);
		}else {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Authentication Failed");
		}
		
	}
	
	@PostMapping("/register")
	public ResponseEntity<UserResponse> registerUser(@RequestBody UserRequest request){
		
		UserResponse response = userAuthService.signup(request);
		if(response.getUsername()!=null) {
			return ResponseEntity.ok(response);
		}else {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
		
	}
}
