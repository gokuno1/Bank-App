package com.amdocs.authorization.service;

import com.amdocs.authorization.dao.UserRequest;
import com.amdocs.authorization.dao.UserResponse;

public interface UserAuthService {

	public String authenticateUser(UserRequest request);
	
	public UserResponse signup(UserRequest input);
	
}
