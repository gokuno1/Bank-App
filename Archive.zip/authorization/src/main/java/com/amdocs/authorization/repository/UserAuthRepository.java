package com.amdocs.authorization.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.amdocs.authorization.model.UserAuth;


@Repository
public interface UserAuthRepository extends JpaRepository<UserAuth, Integer>{

	Optional<UserAuth> findByUsername(String username);
	
}
