//package com.amdocs.gateway.filter;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.cloud.gateway.filter.GatewayFilter;
//import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.http.HttpHeaders;
//
//import com.amdocs.gateway.service.JwtService;
//
//@Configuration
//public class JwtAuthenticationFilterFactory extends AbstractGatewayFilterFactory<JwtAuthenticationFilterFactory.Config>{
//
//	@Autowired
//	private RouteValidationFilter validator;
//	
//	@Autowired
//	private JwtService jwtService;
//	
////	@Autowired
////    private UserDetailsService userDetailsService;
//	
//	public JwtAuthenticationFilter() {
//		
//	}
//	
//	@Override
//	public GatewayFilter apply(Config config) {
//		return ((exchange, chain) -> {
//            if (validator.isSecured.test(exchange.getRequest())) {
//                if (!exchange.getRequest().getHeaders().containsKey(HttpHeaders.AUTHORIZATION)) {
//                    throw new RuntimeException("missing authorization header");
//                }
//
//                String authHeader = exchange.getRequest().getHeaders().get(HttpHeaders.AUTHORIZATION).get(0);
//                if (authHeader != null && authHeader.startsWith("Bearer ")) {
//                    authHeader = authHeader.substring(7);
//                }
//                
////                String username = jwtService.extractUsername(authHeader);
////                UserDetails userdetails = this.userDetailsService.loadUserByUsername(username);
//                try {
////                	if(jwtService.isTokenValid(username, userdetails)) {
////                		return chain.filter(exchange);
////                	}
//                	jwtService.validateToken(authHeader);
//                	
//                } catch (Exception e) {
//                    System.out.println("invalid access...!");
//                    throw new RuntimeException("un authorized access to application");
//                }
//            }
//            return chain.filter(exchange);
//        });
//	}
//	
//	class Config{
//		
//	}
//}
