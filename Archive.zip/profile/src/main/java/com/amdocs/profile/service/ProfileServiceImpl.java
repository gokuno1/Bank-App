package com.amdocs.profile.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.amdocs.profile.dao.UserRequest;
import com.amdocs.profile.dao.UserResponse;
import com.amdocs.profile.model.Profile;
import com.amdocs.profile.repository.ProfileRepository;

@Service
public class ProfileServiceImpl implements ProfileService{
	
	@Autowired
	private ProfileRepository profileRepository;

	@Override
	public UserResponse createProfile(UserRequest request) {
		UserResponse response = new UserResponse();
		Profile profile = new Profile();
		profile.setAddress(request.getAddress());
		profile.setPhoneNumber(request.getPhoneNumber());
		profile.setUsername(request.getUsername());
		profile.setCreatedDate(new Date());
		
		Profile savedProfile = profileRepository.save(profile);
		response.setUsername(savedProfile.getUsername());
		response.setCreatedDate(savedProfile.getCreatedDate());
		return response;
	}


}
