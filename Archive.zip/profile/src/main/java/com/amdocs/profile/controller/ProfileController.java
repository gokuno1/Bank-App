package com.amdocs.profile.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amdocs.profile.dao.UserRequest;
import com.amdocs.profile.dao.UserResponse;
import com.amdocs.profile.service.ProfileService;

@RestController
@RequestMapping("/profile")
public class ProfileController {
	
	@Autowired
	private ProfileService profileService;

	@PostMapping("/")
	public ResponseEntity<UserResponse> helloWorld(@RequestBody UserRequest request) {
		UserResponse response = profileService.createProfile(request);
		if(response.getUsername().isEmpty()) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}else {
			return ResponseEntity.ok(response);
		}
	}
	
}
