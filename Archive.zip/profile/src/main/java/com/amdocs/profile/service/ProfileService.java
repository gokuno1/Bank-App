package com.amdocs.profile.service;

import com.amdocs.profile.dao.UserRequest;
import com.amdocs.profile.dao.UserResponse;

public interface ProfileService {

	UserResponse createProfile(UserRequest request);
	
}
