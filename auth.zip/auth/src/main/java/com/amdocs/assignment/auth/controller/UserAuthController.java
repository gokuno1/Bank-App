package com.amdocs.assignment.auth.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.amdocs.assignment.auth.common.ResponseMessages;
import com.amdocs.assignment.auth.dao.UserAuth;
import com.amdocs.assignment.auth.service.UserAuthService;

@RestController
@RequestMapping("/auth")
public class UserAuthController {

	@Autowired
    private UserAuthService userAuthService;
	
	@PostMapping("/login")
	public ResponseEntity<String> login(@RequestBody UserAuth user) {
		if(userAuthService.login(user).equals(ResponseMessages.AUTHENTICATED)) {
			return ResponseEntity.ok(userAuthService.login(user));
		}else {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Authentication failed");
		}
	}
	
	@PostMapping("/user")
	public ResponseEntity<String> saveUser(@RequestBody UserAuth user) {
		if(userAuthService.save(user)!=null) {
			return ResponseEntity.ok("User saved successfully");
		}else {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to save User");
		}
	}
}
