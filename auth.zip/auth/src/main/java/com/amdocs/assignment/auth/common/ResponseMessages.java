package com.amdocs.assignment.auth.common;

public interface ResponseMessages {

	String AUTHENTICATED = "User authenticated";
	
}
