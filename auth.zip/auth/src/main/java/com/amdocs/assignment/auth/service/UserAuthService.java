package com.amdocs.assignment.auth.service;

import com.amdocs.assignment.auth.dao.UserAuth;


public interface UserAuthService {

	public UserAuth save(UserAuth user);
	public UserAuth findByUsername(String username);
	public String login(UserAuth user);
}
