package com.amdocs.assignment.auth.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.amdocs.assignment.auth.dao.UserAuth;
import com.amdocs.assignment.auth.repository.UserAuthRepository;

@Service
public class UserAuthServiceImpl implements UserAuthService {

	@Autowired
    private UserAuthRepository userAuthRepository;
	
	@Autowired
    private PasswordEncoder passwordEncoder;
		
	@Override
	public UserAuth save(UserAuth user) {
		user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userAuthRepository.save(user);
	}

	@Override
	public UserAuth findByUsername(String username) {
		return userAuthRepository.findByUsername(username);
	}

	@Override
	public String login(UserAuth user) {

			UserAuth userDetails = findByUsername(user.getUsername());
			if(passwordEncoder.matches(user.getPassword(), userDetails.getPassword())){
				return "User authenticated";
			}else {
				return "User Authentication Failed";
			}
            
            
        
	}

}
